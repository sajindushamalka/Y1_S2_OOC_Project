/*Name - Nishshanka N.A.G.A.A
IT Number - IT21032974*/

class PaymentMethod 
{
  private :

    char ptye[10];


  public :

    PaymentMethod();
    PaymentMethod(const char pType[]);
    void diplayMethod();
    ~PaymentMethod();
    
};